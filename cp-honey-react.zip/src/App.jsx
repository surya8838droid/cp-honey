
import React from "react";
import { ShoppingCart } from "lucide-react";

export default function App() {
  return (
    <div className="bg-white text-black min-h-screen font-sans">
      {/* Hero Section */}
      <section className="bg-yellow-50 py-10 px-6 text-center">
        <img
          src="/honey-jar.png"
          alt="CP Honey Jar"
          className="mx-auto w-48 mb-4"
        />
        <h1 className="text-4xl font-bold text-yellow-900">CP HONEY</h1>
        <p className="text-lg text-yellow-800 mt-2">
          Pure From Nature — Nothing Added, Nothing Changed
        </p>
        <button className="mt-4 bg-yellow-600 text-white px-4 py-2 rounded hover:bg-yellow-700">
          Shop Now
        </button>
      </section>

      {/* Product Highlight Section */}
      <section className="py-12 px-4 bg-white text-center">
        <h2 className="text-3xl font-semibold mb-8 text-yellow-900">Our Products</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {[500, 250, 1000].map((size) => (
            <div key={size} className="shadow-md p-4 border rounded">
              <img
                src="/honey-jar.png"
                alt={`${size}g Honey Jar`}
                className="mx-auto w-32 mb-3"
              />
              <h3 className="text-xl font-semibold">{size}g Honey</h3>
              <p className="text-sm text-gray-600 mt-1">No Sugar, No Preservatives</p>
              <button className="mt-3 w-full bg-yellow-600 text-white px-4 py-2 rounded hover:bg-yellow-700 flex justify-center items-center gap-2">
                <ShoppingCart className="h-4 w-4" /> Add to Cart
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Why CP HONEY */}
      <section className="bg-yellow-100 py-10 px-6">
        <h2 className="text-3xl font-bold text-yellow-900 text-center mb-6">
          Why Choose CP HONEY?
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-4xl mx-auto text-center">
          <div><p className="font-semibold text-yellow-800">🐝 100% Raw</p></div>
          <div><p className="font-semibold text-yellow-800">🌿 Organic</p></div>
          <div><p className="font-semibold text-yellow-800">🚫 No Additives</p></div>
          <div><p className="font-semibold text-yellow-800">🧴 Glass Jar</p></div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white text-center py-6 mt-10">
        <p className="text-sm">© 2025 CP HONEY. All rights reserved.</p>
        <p className="text-sm mt-1">Instagram | WhatsApp | Support</p>
      </footer>
    </div>
  );
}
